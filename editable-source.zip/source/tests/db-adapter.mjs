import {DatabaseSync} from 'node:sqlite';import fs from 'node:fs';
export function database(filename=':memory:'){const db=new DatabaseSync(filename);db.exec('PRAGMA foreign_keys = ON');if(db.prepare('PRAGMA user_version').get().user_version===0){for(const file of fs.readdirSync('drizzle').filter(n=>n.endsWith('.sql')).sort())db.exec(fs.readFileSync('drizzle/'+file,'utf8'));db.exec('PRAGMA user_version = 1')}
return{raw:db,prepare(sql){return{bind(...args){return{async run(){return db.prepare(sql).run(...args)},async first(){return db.prepare(sql).get(...args)||null}}}}}}
}

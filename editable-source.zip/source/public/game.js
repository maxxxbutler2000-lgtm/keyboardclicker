(function(root){
const boards=[
{id:'rust',name:'Rustbucket',tag:'SALVAGED FROM THE SCRAPYARD',cost:0,rate:1,sound:'Grinding metal · loose springs',desc:'Corroded steel. Questionable hygiene. A fresh start.',color:'#a16342',engine:'rust',skin:'rust'},
{id:'tin',name:'Tin Rattle',tag:'BARELY HOLDING TOGETHER',cost:80,rate:2,sound:'Hollow clanks · rattly caps',desc:'Less rust. Still sounds like a toolbox falling downstairs.',color:'#9ba8a6',engine:'tin',skin:'tin'},
{id:'office',name:'Office Relic',tag:'AN HONEST DAY’S CLACK',cost:350,rate:4,sound:'Recorded Cherry MX Blue · crisp clicks',desc:'Proper switches. Finally, a little dignity.',color:'#c3bca3',engine:'blue',pitch:1,cutoff:12000,skin:'office'},
{id:'mint',name:'Mint Condition',tag:'CLEAN CAPS. CLEAN CLICKS.',cost:1400,rate:8,sound:'Softened tactile clicks · warm bottom-out',desc:'Fresh keycaps and a smoother, gentler sound.',color:'#8fbea4',engine:'blue',pitch:.85,cutoff:4900,skin:'mint'},
{id:'cream',name:'Velvet Cream',tag:'WELCOME TO THE THOCK SIDE',cost:5500,rate:16,sound:'Recorded NK Cream · deep, rounded thock',desc:'Silky switches. Every press is a little reward.',color:'#d2b6d6',engine:'cream',pitch:.96,cutoff:6500,skin:'cream'}];
const extras=[
['cardboard','Cardboard Clatter','#b99568','Dry, papery clacks in a recycled case.','blue',1.15,8700],
['bottlecap','Bottlecap Board','#8ba2a8','Small metallic ticks, rounded at the edges.','blue',1.08,8100],
['bronze','Bronze Typewriter','#ba895b','Warm bronze caps with a vintage snap.','blue',1.01,7600],
['retro','Retro Terminal','#b9cba2','Chunky old-school keys with a softer touch.','blue',.96,7200],
['walnut','Walnut Workshop','#a28263','A rich wooden case with cozy bottom-out.','blue',.90,6700],
['bamboo','Bamboo Garden','#b4bc86','Light bamboo taps, gentle and airy.','blue',1.03,6300],
['blossom','Cherry Blossom','#e3afbd','Petal-pink caps and soft spring clicks.','blue',.94,5800],
['matcha','Matcha Latte','#a4b383','A mellow, warm cup of tactile sound.','blue',.88,5200],
['bubblegum','Bubblegum Pop','#d39bc0','Bouncy little pops with a playful pitch.','cream',1.18,8500],
['frost','Frosted Glass','#a7c7cf','Crisp glassy taps over a cushioned base.','cream',1.13,7900],
['pebble','Ocean Pebble','#87acb7','Smooth stone taps with a rounded landing.','cream',1.07,7300],
['copper','Copper Circuit','#c58d74','A warm copper clack with no loose edges.','cream',1.02,7000],
['slate','Slate Studio','#8c9ba5','Dense, even taps in a quiet studio.','cream',.98,6500],
['ceramic','Ceramic Cloud','#d6cfbe','Hollow ceramic knocks, cloud-soft underneath.','cream',1.05,6100],
['marble','Marble Mist','#c0c8cc','Smooth marble caps, satisfyingly solid.','cream',.95,5700],
['lavender','Lavender Hush','#baa8cc','A soft purple board with hushed clicks.','cream',.91,5100],
['cocoa','Cocoa Butter','#bd9b88','Low chocolate thocks, rich and buttery.','cream',.86,4500],
['snowdrop','Snowdrop Silk','#d6e2dd','Light, silky presses with a gentle landing.','cream',1.01,4800],
['pixel','Pixel Prism','#a9a4e7','Your first RGB board. Every press paints a wave.','cream',.98,4400],
['neon','Neon Arcade','#e38dbf','Bright rainbow energy with cushioned taps.','cream',1.08,4600],
['aurora','Aurora Glass','#85c8c2','A dancing aurora over silky glasslike taps.','cream',1.04,4300],
['opal','Opal Rain','#bcc9e7','Soft pearly taps, like rain on opal.','cream',.97,4100],
['moonstone','Moonstone Nimbus','#b2b4cf','A pillowy landing with a low moonlit thock.','cream',.92,3900],
['sapphire','Sapphire Satin','#839fcd','Deep blue notes with satin-smooth release.','cream',.89,3700],
['quartz','Rose Quartz','#ddb2c8','Sweet rosy taps with a rounded little pop.','cream',.94,3500],
['emerald','Emerald Echo','#83b69a','Rich green thocks that settle into silence.','cream',.86,3300],
['amethyst','Amethyst Dream','#af96ca','Soft violet notes with a dreamy bottom-out.','cream',.83,3100],
['crystal','Liquid Crystal','#9fcfcf','Flowing rainbow color and liquid-soft taps.','cream',.90,3000],
['nectar','Golden Nectar','#e1b75e','Golden, creamy presses. One step from honey.','cream',.81,2700],
['honeycomb','Honeycomb Reserve','#d5a34a','A plush golden board, tuned for the finale.','cream',.77,2450]
];
extras.forEach(([id,name,color,desc,engine,pitch,cutoff],j)=>{const rate=Math.round(32*1.25**j);boards.push({id,name,color,desc,engine,pitch,cutoff,skin:'custom',rate,cost:Math.round(rate*(240+j*8)/10)*10,rgb:j>=18,tag:j>=18?'THE RAINBOW COLLECTION':'THE MATERIAL COLLECTION',sound:(engine==='blue'?'Cherry MX Blue':'NK Cream')+' · '+['bright','warm','rounded','soft','deep'][j%5]+' tuning'})});
// Bonus illustrated snack boards; stable IDs preserve every existing unlock.
boards.push({id:'lemonade',name:'Lemonade Stand',tag:'FRESHLY SQUEEZED SATISFACTION',cost:11500000,rate:24000,sound:'NK Cream · bright citrus pops',desc:'Iced lemonade, fresh lemons, and tiny citrus keycaps.',color:'#e4c754',engine:'cream',pitch:1.04,cutoff:3900,skin:'custom',rgb:true});
boards.push({id:'cookie',name:'Cookie Crumble',tag:'BAKED TO CLICKY PERFECTION',cost:13200000,rate:27000,sound:'NK Cream · warm cookie thocks',desc:'Chocolate chip cookies and a keyboard fresh from the oven.',color:'#c49a6b',engine:'cream',pitch:.83,cutoff:2900,skin:'custom',rgb:true});
const last=boards.at(-1);boards.push({id:'honey',name:'Honey Drip',tag:'THE SWEETEST ENDGAME',cost:Math.round(Math.round(32*1.25**29)*700/100)*100,rate:Math.round(Math.round(32*1.25**29)*1.5),sound:'Sourced honey ASMR · 13 sticky key samples',desc:'The final board. Golden honey and sourced sticky ASMR.',color:'#e8ad38',engine:'honey',skin:'honey',rgb:true});
const motifs={"rust": ["⚙️", "🔩", "⚙️"], "tin": ["🔩", "⚙️", "🔧"], "office": ["📎", "✏️", "📄"], "mint": ["🌿", "🍃", "🌿"], "cream": ["🍦", "🧁", "☁️"], "cardboard": ["📦", "📦", "♻️"], "bottlecap": ["🧢", "🥤", "🫧"], "bronze": ["⚙️", "🕰️", "⚙️"], "retro": ["👾", "💾", "🕹️"], "walnut": ["🌰", "🍂", "🪵"], "bamboo": ["🎋", "🍃", "🎋"], "blossom": ["🌸", "🌸", "🌷"], "matcha": ["🍵", "🍃", "🍵"], "bubblegum": ["🫧", "🍬", "🫧"], "frost": ["❄️", "🧊", "❄️"], "pebble": ["🐚", "🪨", "🌊"], "copper": ["⚡", "⚙️", "⚡"], "slate": ["⛰️", "🪨", "🏔️"], "ceramic": ["☁️", "🫖", "☁️"], "marble": ["🤍", "🪨", "🤍"], "lavender": ["🪻", "💜", "🪻"], "cocoa": ["🍫", "🍫", "🤎"], "snowdrop": ["❄️", "🎀", "❄️"], "pixel": ["🌈", "✦", "💠"], "neon": ["👾", "🕹️", "⚡"], "aurora": ["🌌", "✨", "🌌"], "opal": ["💎", "💧", "🫧"], "moonstone": ["🌙", "☁️", "🌙"], "sapphire": ["💎", "🔹", "💎"], "quartz": ["💎", "🌸", "🩷"], "emerald": ["💚", "💎", "🍃"], "amethyst": ["💜", "💎", "🔮"], "crystal": ["🔮", "💎", "🫧"], "nectar": ["🌼", "🍯", "🌼"], "honeycomb": ["🐝", "🍯", "🐝"], "honey": ["🍯", "🐝", "🍯"], "lemonade": ["🍋", "🥤", "🍋"], "cookie": ["🍪", "🍪", "🥛"]};boards.forEach(b=>{b.motifs=motifs[b.id]||["✦"]});
function integer(n){n=Number(n);return Number.isFinite(n)?Math.max(0,Math.min(Number.MAX_SAFE_INTEGER,Math.floor(n))):0}
class Game{
constructor(saved={}){saved=saved&&typeof saved==='object'?saved:{};this.coins=integer(saved.coins);this.total=integer(saved.total);const old=['rust','tin','office','mint','cream','honey'];const ids=saved.version===2?saved.ids:old;this.owned=boards.map((b,i)=>i===0||saved.owned?.[ids?.indexOf(b.id)]===true);this.xp=boards.map(b=>integer(saved.xp?.[ids?.indexOf(b.id)]));const activeId=ids?.[saved.active];this.active=Math.max(0,boards.findIndex((b,i)=>b.id===activeId&&this.owned[i]));}
level(i=this.active){return Math.min(10,1+Math.floor(Math.sqrt(this.xp[i]/20)))}next(i=this.active){return this.level(i)>=10?null:20*this.level(i)**2}rate(){const b=boards[this.active];return b.rate+Math.max(this.level()-1,Math.floor(b.rate*.07*(this.level()-1)))}press(){const before=this.level(),gain=this.rate();this.coins=integer(this.coins+gain);this.total++;this.xp[this.active]++;return{gain,leveled:this.level()>before}}unlock(i){if(!boards[i]||this.owned[i]||!this.owned[i-1]||this.coins<boards[i].cost)return false;this.coins-=boards[i].cost;this.owned[i]=true;this.active=i;return true}equip(i){if(!boards[i]||!this.owned[i])return false;this.active=i;return true}save(){return{version:2,ids:boards.map(b=>b.id),coins:this.coins,total:this.total,owned:this.owned,xp:this.xp,active:this.active}}}
// Hover uses stable key-slot geometry, not the animated key. A small dead band absorbs edge jitter.
class HoverGate{constructor(){this.last=null}reset(){this.last=null}move(x,y,cells){const cell=cells.find(c=>x>=c.left+3&&x<=c.right-3&&y>=c.top+3&&y<=c.bottom-3);if(cell){if(this.last===cell.id)return null;this.last=cell.id;return cell.id}const previous=cells.find(c=>c.id===this.last);if(previous&&(x<previous.left-6||x>previous.right+6||y<previous.top-6||y>previous.bottom+6))this.last=null;return null}}
class SecretCode{constructor(){this.buffer=''}push(key){if(key==='Backspace'){this.buffer=this.buffer.slice(0,-1);return false}if(key.length!==1)return false;this.buffer=(this.buffer+key.toLowerCase()).slice(-11);if(this.buffer==='secretpanel'){this.buffer='';return true}return false}}
root.KeydriftGame={Game,boards,HoverGate,SecretCode};
})(typeof window==='undefined'?globalThis:window);

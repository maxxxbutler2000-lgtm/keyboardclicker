import {sqliteTable,text,integer} from 'drizzle-orm/sqlite-core';
export const users=sqliteTable('users',{id:text('id').primaryKey(),email:text('email').notNull(),displayName:text('display_name').notNull(),createdAt:text('created_at').notNull(),lastSeenAt:text('last_seen_at').notNull()});
export const gameSaves=sqliteTable('game_saves',{userId:text('user_id').primaryKey().references(()=>users.id),state:text('state').notNull(),revision:integer('revision').notNull().default(1),updatedAt:text('updated_at').notNull()});

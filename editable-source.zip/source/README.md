# Keydrift

Keyboard ASMR clicker with 38 illustrated keyboards, ten levels per board, late-game rainbow waves, and account-based cloud saves.

Hosted game: https://keydrift-asmr-mb.maxxxbutler2000.chatgpt.site/

## Accounts and storage

ChatGPT sign-in and sign-out are handled by Sites. The production Worker trusts only identity headers supplied by that hosting platform. Each player's progress is stored in Cloudflare D1 under their authenticated user ID. Passwords are never collected by this app.

The first sign-in copies the existing browser game into a new cloud save. Existing cloud saves are restored on later sign-ins. Browser-only progress is kept separately, with an explicit import action in the account menu. Unsynced account changes stay on the device and retry when online; conflicting saves require the player to choose which version to keep.

`public/` contains the game and assets. `worker/index.js` implements the account and progress API. `db/schema.ts` and `drizzle/` define the database. Applied migrations should not be edited; generate new migrations for schema changes.

## Development

Use Node.js 22 or newer and pnpm. Run `pnpm install`, `pnpm test`, and `node scripts/dev.mjs`. The localhost-only preview provides a mock account for testing; it is never included in the production Worker. Preview data is kept in the ignored `.sites-runtime/` directory.

Run `pnpm build` and `node scripts/validate-artifact.mjs` to build and validate `dist/`. The output includes the Worker, assets, hosting manifest, and database migrations. Publish through Sites to provision D1 and its trusted authentication headers. A generic static host cannot run this backend.

## GitHub Pages

The repository's single-file static build embeds the game assets and offers a link to the hosted cloud game for accounts. GitHub Pages itself only saves progress in the browser. Use its `build.py` to rebuild that version from an extracted `source/` folder.

Type `secretpanel` anywhere in the game for developer controls. Sound and artwork credits are in the game footer and `public/assets/SOURCES.txt`.

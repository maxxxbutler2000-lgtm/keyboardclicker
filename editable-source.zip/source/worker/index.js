const apiHeaders={'Content-Type':'application/json; charset=utf-8','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Vary':'Cookie'};
const json=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:apiHeaders});
export function normalizeState(value,boardIds){
 if(!value||value.version!==2||!Array.isArray(value.ids)||!Array.isArray(value.owned)||!Array.isArray(value.xp)||value.ids.length>128||value.ids.length!==value.owned.length||value.ids.length!==value.xp.length)throw new Error('Invalid save format');
 const validInt=(n,max)=>Number.isSafeInteger(n)&&n>=0&&n<=max;
 if(!validInt(value.coins,Number.MAX_SAFE_INTEGER)||!validInt(value.total,1e12)||!validInt(value.active,value.ids.length-1)||new Set(value.ids).size!==value.ids.length||value.ids.some(id=>!boardIds.includes(id))||value.owned.some(v=>typeof v!=='boolean')||value.xp.some(n=>!validInt(n,1e9)))throw new Error('Invalid save values');
 const owned=boardIds.map((id,i)=>i===0||value.owned[value.ids.indexOf(id)]===true),xp=boardIds.map(id=>value.xp[value.ids.indexOf(id)]||0);const active=Math.max(0,boardIds.findIndex((id,i)=>id===value.ids[value.active]&&owned[i]));
 return{version:2,ids:boardIds,coins:value.coins,total:value.total,owned,xp,active};
}
export function getUser(request){const id=request.headers.get('oai-authenticated-user-id'),email=request.headers.get('oai-authenticated-user-email');if(!id||!email||id.length>256||email.length>320)return null;let name=email;const raw=request.headers.get('oai-authenticated-user-full-name');if(raw&&request.headers.get('oai-authenticated-user-full-name-encoding')==='percent-encoded-utf-8'){try{name=decodeURIComponent(raw)}catch{}}return{id,email,displayName:name.slice(0,160)}}
export function createApp({assets={},boardIds=[]}={}){return{async fetch(request,env){
 const url=new URL(request.url),path=url.pathname;
 if(path.startsWith('/api/')){
  const user=getUser(request);if(!user)return json({error:'Sign in to access your account.'},401);
  if(!env.DB)return json({error:'Cloud storage is temporarily unavailable.'},503);
  try{
   if(path==='/api/account'&&request.method==='GET'){
    const now=new Date().toISOString();await env.DB.prepare('INSERT INTO users (id,email,display_name,created_at,last_seen_at) VALUES (?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET email=excluded.email,display_name=excluded.display_name,last_seen_at=excluded.last_seen_at').bind(user.id,user.email,user.displayName,now,now).run();
    const row=await env.DB.prepare('SELECT state,revision,updated_at FROM game_saves WHERE user_id=?').bind(user.id).first();
    return json({user,progress:row?{state:JSON.parse(row.state),revision:row.revision,updatedAt:row.updated_at}:null});
   }
   if(path==='/api/progress'&&request.method==='PUT'){
    if(request.headers.get('Origin')!==url.origin)return json({error:'This save must come from the game.'},403);
    if(!request.headers.get('Content-Type')?.startsWith('application/json'))return json({error:'JSON is required.'},415);
    if(Number(request.headers.get('Content-Length'))>65536)return json({error:'Save is too large.'},413);
    const chunks=[];let size=0;const reader=request.body?.getReader();if(reader){while(true){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>65536){await reader.cancel();return json({error:'Save is too large.'},413)}chunks.push(part.value)}}const joined=new Uint8Array(size);let offset=0;for(const chunk of chunks){joined.set(chunk,offset);offset+=chunk.length}const raw=new TextDecoder().decode(joined);
    let body,state;try{body=JSON.parse(raw);state=normalizeState(body.state,boardIds);if(!Number.isSafeInteger(body.revision)||body.revision<0||body.revision>1e9)throw Error()}catch{return json({error:'The save data is invalid.'},400)}
    const exists=await env.DB.prepare('SELECT id FROM users WHERE id=?').bind(user.id).first();if(!exists)return json({error:'Load your account before saving.'},409);
    const now=new Date().toISOString(),serialized=JSON.stringify(state);let result;
    if(body.revision===0)result=await env.DB.prepare('INSERT INTO game_saves (user_id,state,revision,updated_at) VALUES (?,?,1,?) ON CONFLICT(user_id) DO NOTHING RETURNING revision,updated_at').bind(user.id,serialized,now).first();
    else result=await env.DB.prepare('UPDATE game_saves SET state=?,revision=revision+1,updated_at=? WHERE user_id=? AND revision=? RETURNING revision,updated_at').bind(serialized,now,user.id,body.revision).first();
    if(!result)return json({error:'Your cloud save changed on another device. Choose which progress to keep.',conflict:true},409);
    return json({revision:result.revision,updatedAt:result.updated_at});
   }
   return json({error:'Not found.'},404);
  }catch{return json({error:'Cloud storage is temporarily unavailable. Your device save is safe.'},503)}
 }
 if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
 let filename;try{filename=decodeURIComponent(path==='/'?'/index.html':path)}catch{return new Response('Not found',{status:404})}
 const asset=assets[filename];if(!asset)return new Response('Not found',{status:404});
 const bytes=request.method==='HEAD'?null:Uint8Array.from(atob(asset.data),c=>c.charCodeAt(0));return new Response(bytes,{headers:{'Content-Type':asset.type,'Cache-Control':filename.endsWith('.html')?'no-cache':'public, max-age=300','X-Content-Type-Options':'nosniff'}});
}}}
export default createApp(/* DEPLOYMENT_DATA */);
